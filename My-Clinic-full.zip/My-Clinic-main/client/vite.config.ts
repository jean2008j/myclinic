import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' = relative asset paths, so the build works on GitHub Pages under /<repo>/ and on any other host.
// Routing uses HashRouter, so no server rewrite rules are needed.
export default defineConfig({
  base: './',
  plugins: [react()],
  server: { port: 5173 },
});
