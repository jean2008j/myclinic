// Data layer on top of Supabase. Every function keeps the same name and result shape the pages already use.
// Errors are normalised to ApiError(code): the code is the text raised by the SQL functions
// ('slot_unavailable', 'cannot_modify', ...) and is turned into a translated message by lib/errors.ts.
import type { Session } from '@supabase/supabase-js';
import { supabase } from './supabase';
import { todayYmd } from './dates';

export class ApiError extends Error {
  constructor(public status: number, public code: string) {
    super(code);
  }
}

interface PgError { message?: string; code?: string; status?: number }

function toApiError(e: PgError | null | undefined): ApiError {
  const msg = e?.message ?? '';
  if (/^[a-z_]+$/.test(msg)) return new ApiError(e?.status ?? 400, msg);   // raise exception 'code'
  if (e?.code === '42501') return new ApiError(403, 'forbidden');          // blocked by RLS / grants
  if (e?.code === 'PGRST116') return new ApiError(404, 'not_found');       // .single() found no row
  if (e?.code?.startsWith('PGRST3') || /jwt/i.test(msg)) return new ApiError(401, 'invalid_token');
  if (/failed to fetch|networkerror|load failed/i.test(msg) || e?.status === 0) return new ApiError(0, 'network');
  return new ApiError(e?.status ?? 500, 'unknown');
}

/** Await a Supabase query/rpc and return its data, or throw ApiError. */
async function run<T>(q: PromiseLike<{ data: unknown; error: PgError | null }>): Promise<T> {
  let res: { data: unknown; error: PgError | null };
  try { res = await q; } catch { throw new ApiError(0, 'network'); }
  if (res.error) throw toApiError(res.error);
  return res.data as T;
}

const iso = (ts: string) => new Date(ts).toISOString();
const firstName = (n: string) => String(n).trim().split(/\s+/)[0];

// ---------- types shared with the server (batch 2 responses) ----------

export interface Service {
  id: number;
  name_ar: string; name_en: string;
  description_ar: string; description_en: string;
  duration_min: number;
}

export interface Provider {
  id: number;
  name_ar: string; name_en: string;
  specialty_ar: string; specialty_en: string;
  bio_ar: string; bio_en: string;
  serviceIds: number[];
  ratingAvg: number | null;
  ratingCount: number;
}

export type Role = 'admin' | 'provider';
export interface AuthUser { id: string; role: Role; providerId: number | null }

export interface Slot { start: string; end: string; time: string }
export interface DayAvail { date: string; slots: number; holiday: boolean }
export type AppointmentStatus = 'confirmed' | 'cancelled' | 'completed' | 'no_show';

export interface Appointment {
  id: number;
  manageToken: string;
  status: AppointmentStatus;
  startAt: string;
  endAt: string;
  provider: { id: number; nameAr: string; nameEn: string };
  service: { id: number; nameAr: string; nameEn: string; durationMin: number };
  patient: { name: string; phone: string; email: string | null; notes: string | null };
  lang: 'ar' | 'en';
  canModify: boolean;
  review: { rating: number; comment: string | null } | null;
  canReview: boolean;
}

export interface PatientInput { patientName: string; phone: string; email?: string; notes?: string }
export interface BookingInput extends PatientInput { providerId: number; serviceId: number; start: string; lang: 'ar' | 'en' }

export interface PublicReview {
  id: number; rating: number; comment: string | null; createdAt: string; name: string;
  provider: { id: number; nameAr: string; nameEn: string };
}

export const publicApi = {
  services: () =>
    run<Service[]>(supabase.from('services')
      .select('id,name_ar,name_en,description_ar,description_en,duration_min')
      .eq('active', true).order('id')),
  providers: (serviceId?: number) =>
    run<Provider[]>(supabase.rpc('list_providers', { p_service: serviceId ?? null })),
  /** `token` = the patient's own booking, so its current time still counts as free while rescheduling */
  availability: (providerId: number, serviceId: number, month: string, token?: string) =>
    run<{ cal_date: string; free_slots: number; is_holiday: boolean }[]>(
      supabase.rpc('month_availability', { p_provider: providerId, p_service: serviceId, p_month: month, p_token: token ?? null }),
    ).then((rows): DayAvail[] => rows.map((r) => ({ date: r.cal_date, slots: r.free_slots, holiday: r.is_holiday }))),
  slots: (providerId: number, serviceId: number, date: string, token?: string) =>
    run<{ slot_start: string; slot_end: string; slot_time: string }[]>(
      supabase.rpc('get_slots', { p_provider: providerId, p_service: serviceId, p_date: date, p_token: token ?? null }),
    ).then((rows): Slot[] => rows.map((r) => ({ start: iso(r.slot_start), end: iso(r.slot_end), time: r.slot_time }))),
  holidays: () =>
    run<Holiday[]>(supabase.from('holidays').select('id,provider_id,day,reason_ar,reason_en')
      .gte('day', todayYmd()).order('day')),
  reviews: (limit = 12) => run<PublicReview[]>(supabase.rpc('public_reviews', { p_provider: null, p_limit: limit })),
  review: (token: string, body: { rating: number; comment?: string }) =>
    run<Appointment>(supabase.rpc('create_review', { p_token: token, p_rating: body.rating, p_comment: body.comment ?? null })),
  book: (b: BookingInput) =>
    run<Appointment>(supabase.rpc('create_appointment', {
      p_provider: b.providerId, p_service: b.serviceId, p_start: b.start,
      p_name: b.patientName, p_phone: b.phone, p_email: b.email ?? null, p_notes: b.notes ?? null, p_lang: b.lang,
    })),
  getBooking: (token: string) => run<Appointment>(supabase.rpc('get_appointment', { p_token: token })),
  updateBooking: (token: string, body: Partial<PatientInput> & { start?: string }) =>
    run<Appointment>(supabase.rpc('update_appointment', { p_token: token, p_patch: body })),
  cancelBooking: (token: string) => run<Appointment>(supabase.rpc('cancel_appointment', { p_token: token })),
};

/** Role + doctor id of the signed-in Supabase user (null if there is no session). */
async function loadUser(): Promise<AuthUser | null> {
  let session: Session | null;
  try { session = (await supabase.auth.getSession()).data.session; } catch { throw new ApiError(0, 'network'); }
  if (!session) return null;
  const uid = session.user.id;
  const profile = await run<{ role: Role } | null>(supabase.from('profiles').select('role').eq('id', uid).maybeSingle());
  if (!profile) throw new ApiError(403, 'forbidden');   // has an Auth account but no row in `profiles`
  const prov = await run<{ id: number } | null>(supabase.from('providers').select('id').eq('user_id', uid).maybeSingle());
  return { id: uid, role: profile.role, providerId: prov?.id ?? null };
}

export const authApi = {
  login: async (email: string, password: string): Promise<AuthUser> => {
    let error: PgError | null;
    try { error = (await supabase.auth.signInWithPassword({ email, password })).error; } catch { throw new ApiError(0, 'network'); }
    if (error) {
      const bad = error.status === 400 || /invalid login/i.test(error.message ?? '');
      throw bad ? new ApiError(401, 'invalid_credentials') : toApiError(error);
    }
    try {
      const u = await loadUser();
      if (!u) throw new ApiError(401, 'unauthorized');
      return u;
    } catch (e) {
      await supabase.auth.signOut();
      throw e;
    }
  },
  me: () => loadUser(),
  logout: async () => { await supabase.auth.signOut(); },
};

// ---------- admin (needs the admin login) ----------

export interface Holiday { id: number; provider_id: number | null; day: string; reason_ar: string; reason_en: string }

export interface AdminAppointment {
  id: number;
  status: AppointmentStatus;
  start_at: string;
  end_at: string;
  patient_name: string;
  phone: string;
  email: string | null;
  notes: string | null;
  lang: 'ar' | 'en';
  provider_id: number;
  provider_name_en: string; provider_name_ar: string;
  service_id: number;
  service_name_en: string; service_name_ar: string;
  duration_min: number;
}

interface CountRow { id: number; nameAr: string; nameEn: string; count: number }
export interface Stats {
  range: { from: string; to: string };
  totals: { total: number; confirmed: number; completed: number; cancelled: number; noShow: number };
  byWeekday: number[]; // 0 = Sunday
  byHour: number[];    // 0..23
  byService: CountRow[];
  byProvider: CountRow[];
  byDay: { date: string; count: number }[];
}

const setStatus = (id: number, status: AppointmentStatus) =>
  run<{ id: number; status: AppointmentStatus }>(
    supabase.from('appointments').update({ status }).eq('id', id).select('id,status').single(),
  ).then((appointment) => ({ appointment }));

export const adminApi = {
  appointments: (p: { from: string; to: string; providerId?: number }) =>
    run<AdminAppointment[]>(supabase.rpc('staff_appointments', { p_from: p.from, p_to: p.to, p_provider: p.providerId ?? null })),
  setStatus,
  stats: (p: { from: string; to: string; providerId?: number }) =>
    run<Stats>(supabase.rpc('admin_stats', { p_from: p.from, p_to: p.to, p_provider: p.providerId ?? null })),
  holidays: () =>
    run<Holiday[]>(supabase.from('holidays').select('id,provider_id,day,reason_ar,reason_en')
      .gte('day', todayYmd()).order('day')),
  addHoliday: (b: { day: string; providerId: number | null; reasonAr: string; reasonEn: string }) =>
    run<{ id: number; affectedAppointments: number }>(supabase.rpc('admin_add_holiday', {
      p_day: b.day, p_provider: b.providerId, p_reason_ar: b.reasonAr, p_reason_en: b.reasonEn,
    })),
  deleteHoliday: async (id: number) => {
    await run(supabase.from('holidays').delete().eq('id', id));
    return { ok: true as const };
  },
};

export interface AdminReview {
  id: number; rating: number; comment: string | null; approved: boolean; createdAt: string; startAt: string;
  patientName: string;
  provider: { nameAr: string; nameEn: string };
  service: { nameAr: string; nameEn: string };
}

interface ReviewRow {
  id: number; rating: number; comment: string | null; approved: boolean; created_at: string;
  appointment: { patient_name: string; start_at: string; service: { name_ar: string; name_en: string } };
  provider?: { name_ar: string; name_en: string };
}
const REVIEW_SELECT = 'id,rating,comment,approved,created_at,appointment:appointments(patient_name,start_at,service:services(name_ar,name_en))';

export const adminReviewsApi = {
  list: async (status: 'pending' | 'approved' | 'all'): Promise<AdminReview[]> => {
    let q = supabase.from('reviews').select(`${REVIEW_SELECT},provider:providers(name_ar,name_en)`);
    if (status === 'pending') q = q.eq('approved', false);
    if (status === 'approved') q = q.eq('approved', true);
    const rows = await run<ReviewRow[]>(q.order('created_at', { ascending: false }).limit(200));
    return rows.map((r) => ({
      id: r.id, rating: r.rating, comment: r.comment, approved: r.approved,
      createdAt: r.created_at, startAt: r.appointment.start_at,
      patientName: r.appointment.patient_name,
      provider: { nameAr: r.provider?.name_ar ?? '', nameEn: r.provider?.name_en ?? '' },
      service: { nameAr: r.appointment.service.name_ar, nameEn: r.appointment.service.name_en },
    }));
  },
  setApproved: (id: number, approved: boolean) =>
    run<{ id: number; approved: boolean }>(supabase.from('reviews').update({ approved }).eq('id', id).select('id,approved').single())
      .then((review) => ({ review })),
  remove: async (id: number) => {
    await run(supabase.from('reviews').delete().eq('id', id));
    return { ok: true as const };
  },
};

// ---------- doctor panel (needs the doctor login) ----------

export interface DoctorReview {
  id: number; rating: number; comment: string | null; approved: boolean; createdAt: string; startAt: string;
  name: string; service: { nameAr: string; nameEn: string };
}
export interface Rating { avg: number | null; count: number }

const ratingOf = (rows: { rating: number; approved: boolean }[]): Rating => {
  const ok = rows.filter((r) => r.approved);
  return { avg: ok.length ? Math.round((ok.reduce((n, r) => n + r.rating, 0) / ok.length) * 10) / 10 : null, count: ok.length };
};

export const providerApi = {
  me: async () => {
    const u = await loadUser();
    if (!u?.providerId) throw new ApiError(403, 'forbidden');
    const [provider, reviews] = await Promise.all([
      run<{ id: number; name_ar: string; name_en: string; specialty_ar: string; specialty_en: string }>(
        supabase.from('providers').select('id,name_ar,name_en,specialty_ar,specialty_en').eq('id', u.providerId).single()),
      run<{ rating: number; approved: boolean }[]>(supabase.from('reviews').select('rating,approved').eq('provider_id', u.providerId)),
    ]);
    return { provider, rating: ratingOf(reviews) };
  },
  // The SQL function forces a doctor's own bookings only, whatever is passed.
  appointments: (day: string) =>
    run<AdminAppointment[]>(supabase.rpc('staff_appointments', { p_from: day, p_to: day, p_provider: null })),
  setStatus: (id: number, status: 'confirmed' | 'completed' | 'no_show') => setStatus(id, status),
  reviews: async () => {
    // RLS: a doctor can only read reviews of their own patients.
    const rows = await run<ReviewRow[]>(
      supabase.from('reviews').select(REVIEW_SELECT).order('created_at', { ascending: false }).limit(200),
    );
    return {
      rating: ratingOf(rows),
      pending: rows.filter((r) => !r.approved).length,
      reviews: rows.map((r): DoctorReview => ({
        id: r.id, rating: r.rating, comment: r.comment, approved: r.approved,
        createdAt: r.created_at, startAt: r.appointment.start_at,
        name: firstName(r.appointment.patient_name),
        service: { nameAr: r.appointment.service.name_ar, nameEn: r.appointment.service.name_en },
      })),
    };
  },
};
