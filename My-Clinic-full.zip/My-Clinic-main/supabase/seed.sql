-- Demo data (same as the old server/src/seed.ts). Run once in Supabase -> SQL Editor, after the migration.
-- Skips itself if services already exist, so running it twice is harmless.
do $$
declare
  v_sara bigint; v_omar bigint;
  s1 bigint; s2 bigint; s3 bigint; s4 bigint; s5 bigint; s6 bigint;
  d int;
begin
  if exists (select 1 from public.services) then
    raise notice 'Seed skipped: services already exist.';
    return;
  end if;

  insert into public.providers (name_ar, name_en, specialty_ar, specialty_en, bio_ar, bio_en) values
    ('د. سارة الأحمد', 'Dr. Sara Al-Ahmad', 'طب أسنان عام', 'General Dentistry',
     'خبرة أكثر من 10 سنوات في طب الأسنان العام والتجميلي.',
     'Over 10 years of experience in general and cosmetic dentistry.')
  returning id into v_sara;
  insert into public.providers (name_ar, name_en, specialty_ar, specialty_en, bio_ar, bio_en) values
    ('د. عمر خليل', 'Dr. Omar Khalil', 'جراحة وزراعة أسنان', 'Oral Surgery & Implants',
     'متخصص بزراعة الأسنان وجراحة الفم.',
     'Specialist in dental implants and oral surgery.')
  returning id into v_omar;

  insert into public.services (name_ar, name_en, duration_min) values ('كشف واستشارة',      'Check-up & Consultation', 20) returning id into s1;
  insert into public.services (name_ar, name_en, duration_min) values ('تنظيف الأسنان',      'Teeth Cleaning',          30) returning id into s2;
  insert into public.services (name_ar, name_en, duration_min) values ('حشو سن',             'Dental Filling',          45) returning id into s3;
  insert into public.services (name_ar, name_en, duration_min) values ('تبييض الأسنان',      'Teeth Whitening',         60) returning id into s4;
  insert into public.services (name_ar, name_en, duration_min) values ('علاج عصب',           'Root Canal Treatment',    90) returning id into s5;
  insert into public.services (name_ar, name_en, duration_min) values ('زراعة سن (استشارة)', 'Implant Consultation',    30) returning id into s6;

  insert into public.provider_services (provider_id, service_id) values
    (v_sara, s1), (v_sara, s2), (v_sara, s3), (v_sara, s4), (v_sara, s5),
    (v_omar, s1), (v_omar, s3), (v_omar, s5), (v_omar, s6);

  -- Mon-Fri 09:00-13:00 and 14:00-17:30 (weekday 0 = Sunday). Dr. Omar also Saturday morning.
  for d in 1..5 loop
    insert into public.working_hours (provider_id, weekday, start_time, end_time) values
      (v_sara, d, '09:00', '13:00'), (v_sara, d, '14:00', '17:30'),
      (v_omar, d, '09:00', '13:00'), (v_omar, d, '14:00', '17:30');
  end loop;
  insert into public.working_hours (provider_id, weekday, start_time, end_time) values (v_omar, 6, '09:00', '13:00');
end $$;
