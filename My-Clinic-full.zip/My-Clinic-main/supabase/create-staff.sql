-- Link staff to their login. Do this AFTER seed.sql.
--
-- 1) Supabase Dashboard -> Authentication -> Users -> "Add user" -> "Create new user"
--    (tick "Auto Confirm User"). Create the admin and one account per doctor, with REAL passwords.
-- 2) Put the same emails below and run this in the SQL Editor.

-- Admin
insert into public.profiles (id, role)
select id, 'admin' from auth.users where email = 'admin@your-clinic.com'
on conflict (id) do update set role = excluded.role;

-- Doctor accounts: link the login to the doctor row and give it the 'provider' role
update public.providers set user_id = (select id from auth.users where email = 'dr.sara@your-clinic.com')
 where name_en = 'Dr. Sara Al-Ahmad';
update public.providers set user_id = (select id from auth.users where email = 'dr.omar@your-clinic.com')
 where name_en = 'Dr. Omar Khalil';

insert into public.profiles (id, role)
select user_id, 'provider' from public.providers where user_id is not null
on conflict (id) do update set role = excluded.role;
