-- =====================================================================
-- Clinic booking on Supabase (Postgres)
-- Replaces the SQLite file + Express server.
--  * Staff log in with Supabase Auth (email + password); role lives in `profiles`.
--  * Patients stay anonymous: they use SECURITY DEFINER functions that take the
--    secret manage_token. Nothing in `appointments` is readable by `anon`.
--  * Double booking is impossible: a GiST exclusion constraint on (provider, time range)
--    + an advisory lock inside the booking function.
-- Errors are raised as plain codes ('slot_unavailable', 'cannot_modify', ...);
-- the client turns them into translated messages.
-- =====================================================================

create extension if not exists btree_gist;

-- ---------------------------------------------------------------- settings
create table public.clinic_settings (
  id                     boolean primary key default true check (id),   -- exactly one row
  tz                     text not null default 'Europe/Amsterdam',
  slot_step_min          int  not null default 15,
  min_notice_min         int  not null default 60,
  max_advance_days       int  not null default 60,
  change_cutoff_hours    int  not null default 2,
  max_upcoming_per_phone int  not null default 3
);
insert into public.clinic_settings default values;
alter table public.clinic_settings enable row level security;   -- no policies: only functions read it

-- ---------------------------------------------------------------- tables
create table public.profiles (
  id   uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','provider'))
);

create table public.providers (
  id           bigint generated always as identity primary key,
  user_id      uuid unique references auth.users(id) on delete set null,
  name_ar      text not null,
  name_en      text not null,
  specialty_ar text not null default '',
  specialty_en text not null default '',
  bio_ar       text not null default '',
  bio_en       text not null default '',
  active       boolean not null default true
);

create table public.services (
  id             bigint generated always as identity primary key,
  name_ar        text not null,
  name_en        text not null,
  description_ar text not null default '',
  description_en text not null default '',
  duration_min   int  not null check (duration_min between 5 and 480),
  active         boolean not null default true
);

create table public.provider_services (
  provider_id bigint not null references public.providers(id) on delete cascade,
  service_id  bigint not null references public.services(id)  on delete cascade,
  primary key (provider_id, service_id)
);

-- weekday: 0 = Sunday ... 6 = Saturday (same as Postgres extract(dow)). Times are clinic-local.
create table public.working_hours (
  id          bigint generated always as identity primary key,
  provider_id bigint not null references public.providers(id) on delete cascade,
  weekday     int  not null check (weekday between 0 and 6),
  start_time  time not null,
  end_time    time not null,
  check (end_time > start_time)
);
create index working_hours_provider_idx on public.working_hours(provider_id, weekday);

-- provider_id NULL = whole clinic closed
create table public.holidays (
  id          bigint generated always as identity primary key,
  provider_id bigint references public.providers(id) on delete cascade,
  day         date not null,
  reason_ar   text not null default '',
  reason_en   text not null default ''
);
create unique index holidays_unique_idx on public.holidays (coalesce(provider_id, 0), day);

create table public.appointments (
  id           bigint generated always as identity primary key,
  provider_id  bigint not null references public.providers(id),
  service_id   bigint not null references public.services(id),
  patient_name text not null,
  phone        text not null,
  email        text,
  notes        text,
  start_at     timestamptz not null,
  end_at       timestamptz not null,
  status       text not null default 'confirmed'
               check (status in ('confirmed','cancelled','completed','no_show')),
  manage_token text not null unique default replace(gen_random_uuid()::text, '-', ''),
  lang         text not null default 'ar' check (lang in ('ar','en')),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  check (end_at > start_at),
  -- Real overlap protection (a 90-min root canal blocks the 30-min slots inside it).
  constraint no_overlap exclude using gist (
    provider_id with =,
    tstzrange(start_at, end_at) with &&
  ) where (status <> 'cancelled')
);
create index appointments_start_idx          on public.appointments(start_at);
create index appointments_provider_start_idx on public.appointments(provider_id, start_at);
create index appointments_phone_idx          on public.appointments(phone);

create table public.reviews (
  id             bigint generated always as identity primary key,
  appointment_id bigint not null unique references public.appointments(id) on delete cascade,
  provider_id    bigint not null references public.providers(id),
  rating         int not null check (rating between 1 and 5),
  comment        text,
  approved       boolean not null default false,
  created_at     timestamptz not null default now()
);
create index reviews_provider_idx on public.reviews(provider_id) where approved;

-- ---------------------------------------------------------------- helpers
create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
$$;

create function public.my_provider_id() returns bigint
language sql stable security definer set search_path = public as $$
  select id from public.providers where user_id = auth.uid()
$$;

-- updated_at + status rules (a cancelled booking stays cancelled; only the admin may cancel from the dashboard)
create function public.appointments_guard() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  if tg_op = 'UPDATE' and new.status is distinct from old.status then
    if old.status = 'cancelled' then
      raise exception 'invalid_status_change';
    end if;
    -- current_user is 'authenticated' for direct staff updates and the function owner inside
    -- cancel_appointment(), so patients can cancel with their token but a doctor cannot cancel from the panel.
    if new.status = 'cancelled' and current_user = 'authenticated' and not public.is_admin() then
      raise exception 'forbidden';
    end if;
  end if;
  return new;
end $$;
create trigger appointments_guard before update on public.appointments
  for each row execute function public.appointments_guard();

-- ---------------------------------------------------------------- row level security
alter table public.profiles          enable row level security;
alter table public.providers         enable row level security;
alter table public.services          enable row level security;
alter table public.provider_services enable row level security;
alter table public.working_hours     enable row level security;
alter table public.holidays          enable row level security;
alter table public.appointments      enable row level security;
alter table public.reviews           enable row level security;

-- Start from nothing, then grant only what is needed.
revoke all on public.profiles, public.providers, public.services, public.provider_services,
              public.working_hours, public.holidays, public.appointments, public.reviews
  from anon, authenticated;

-- profiles: a user reads only their own row (to learn the role)
grant select on public.profiles to authenticated;
create policy profiles_self on public.profiles for select to authenticated using (id = auth.uid());

-- catalogue: public read. providers.user_id is NOT readable by the public (column grant).
grant select (id, name_ar, name_en, specialty_ar, specialty_en, bio_ar, bio_en, active)
  on public.providers to anon, authenticated;
grant select on public.services, public.provider_services, public.holidays to anon, authenticated;
grant select (user_id) on public.providers to authenticated;
create policy providers_read_public on public.providers for select to anon using (active);
create policy providers_read_staff  on public.providers for select to authenticated
  using (active or public.is_admin() or user_id = auth.uid());
create policy services_read  on public.services  for select to anon, authenticated
  using (active or public.is_admin());
create policy provider_services_read on public.provider_services for select to anon, authenticated using (true);
create policy holidays_read  on public.holidays  for select to anon, authenticated using (true);

-- admin manages the catalogue and days off (admin screens for this can be added later)
grant insert, update, delete on public.providers, public.services, public.provider_services,
                               public.working_hours, public.holidays to authenticated;
grant select on public.working_hours to authenticated;
create policy providers_admin  on public.providers  for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy services_admin   on public.services   for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy provider_services_admin on public.provider_services for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy working_hours_admin on public.working_hours for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy holidays_admin   on public.holidays   for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy working_hours_own on public.working_hours for select to authenticated using (provider_id = public.my_provider_id());

-- appointments: staff only. Admin = all, doctor = own. The only column staff can change is `status`.
grant select on public.appointments to authenticated;
grant update (status) on public.appointments to authenticated;
create policy appointments_admin_read   on public.appointments for select to authenticated using (public.is_admin());
create policy appointments_admin_update on public.appointments for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy appointments_own_read     on public.appointments for select to authenticated using (provider_id = public.my_provider_id());
create policy appointments_own_update   on public.appointments for update to authenticated
  using (provider_id = public.my_provider_id()) with check (provider_id = public.my_provider_id());

-- reviews: admin moderates, doctor reads own. The public reads only through public_reviews().
grant select, delete on public.reviews to authenticated;
grant update (approved) on public.reviews to authenticated;
create policy reviews_admin_read   on public.reviews for select to authenticated using (public.is_admin());
create policy reviews_admin_update on public.reviews for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy reviews_admin_delete on public.reviews for delete to authenticated using (public.is_admin());
create policy reviews_own_read     on public.reviews for select to authenticated using (provider_id = public.my_provider_id());

-- ---------------------------------------------------------------- input cleaning (shared)
create function public._clean_name(p text) returns text
language plpgsql immutable as $$
declare v text := btrim(coalesce(p, ''));
begin
  if char_length(v) < 2 or char_length(v) > 100 then raise exception 'validation_error'; end if;
  return v;
end $$;

-- Arabic-Indic and Persian digits -> Latin, strip spaces/dashes/brackets.
create function public._clean_phone(p text) returns text
language plpgsql immutable as $$
declare v text;
begin
  v := regexp_replace(
         translate(coalesce(p, ''), '٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789'),
         '[\s\-()]', '', 'g');
  if v !~ '^\+?[0-9]{6,15}$' then raise exception 'validation_error'; end if;
  return v;
end $$;

create function public._clean_email(p text) returns text
language plpgsql immutable as $$
declare v text := nullif(btrim(coalesce(p, '')), '');
begin
  if v is not null and (char_length(v) > 120 or v !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$') then
    raise exception 'validation_error';
  end if;
  return v;
end $$;

create function public._clean_notes(p text) returns text
language plpgsql immutable as $$
declare v text := nullif(btrim(coalesce(p, '')), '');
begin
  if v is not null and char_length(v) > 500 then raise exception 'validation_error'; end if;
  return v;
end $$;

-- ---------------------------------------------------------------- appointment -> JSON (same shape the website already uses)
create function public._appt_json(a public.appointments) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  p public.providers; s public.services; r public.reviews; c public.clinic_settings;
begin
  select * into p from public.providers where id = a.provider_id;
  select * into s from public.services  where id = a.service_id;
  select * into r from public.reviews   where appointment_id = a.id;
  select * into c from public.clinic_settings;
  return jsonb_build_object(
    'id', a.id,
    'manageToken', a.manage_token,
    'status', a.status,
    'startAt', to_char(a.start_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
    'endAt',   to_char(a.end_at   at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
    'provider', jsonb_build_object('id', p.id, 'nameAr', p.name_ar, 'nameEn', p.name_en),
    'service',  jsonb_build_object('id', s.id, 'nameAr', s.name_ar, 'nameEn', s.name_en, 'durationMin', s.duration_min),
    'patient',  jsonb_build_object('name', a.patient_name, 'phone', a.phone, 'email', a.email, 'notes', a.notes),
    'lang', a.lang,
    'canModify', a.status = 'confirmed' and a.start_at > now() + make_interval(hours => c.change_cutoff_hours),
    'review', case when r.id is null then null
                   else jsonb_build_object('rating', r.rating, 'comment', r.comment) end,
    'canReview', a.status = 'completed' and r.id is null
  );
end $$;

create function public._can_modify(a public.appointments) returns boolean
language sql stable security definer set search_path = public as $$
  select a.status = 'confirmed'
     and a.start_at > now() + make_interval(hours => (select change_cutoff_hours from public.clinic_settings))
$$;

create function public._by_token(p_token text, p_lock boolean default false) returns public.appointments
language plpgsql security definer set search_path = public as $$
declare a public.appointments;
begin
  if p_token is null or p_token !~ '^[0-9a-f]{32}$' then raise exception 'not_found'; end if;
  if p_lock then
    select * into a from public.appointments where manage_token = p_token for update;
  else
    select * into a from public.appointments where manage_token = p_token;
  end if;
  if a.id is null then raise exception 'not_found'; end if;
  return a;
end $$;

-- ---------------------------------------------------------------- availability
-- Free start times of one clinic-local day (working hours, days off, no overlap, min notice, max days ahead).
-- p_token = the patient's own booking, so its current time counts as free while rescheduling.
create function public.get_slots(p_provider bigint, p_service bigint, p_date date, p_token text default null)
returns table (slot_start timestamptz, slot_end timestamptz, slot_time text)
language plpgsql stable security definer set search_path = public as $$
declare
  c public.clinic_settings; v_dur int; v_excl bigint := 0; v_today date;
begin
  select * into c from public.clinic_settings;

  select s.duration_min into v_dur
    from public.services s
    join public.provider_services ps on ps.service_id = s.id and ps.provider_id = p_provider
    join public.providers p on p.id = ps.provider_id
   where s.id = p_service and s.active and p.active;
  if v_dur is null then raise exception 'not_found'; end if;

  if p_token is not null then
    select a.id into v_excl from public.appointments a where a.manage_token = p_token;
  end if;
  v_excl := coalesce(v_excl, 0);

  v_today := (now() at time zone c.tz)::date;
  if p_date < v_today or p_date > v_today + c.max_advance_days then return; end if;
  if exists (select 1 from public.holidays h
              where h.day = p_date and (h.provider_id is null or h.provider_id = p_provider)) then
    return;
  end if;

  return query
  select (g.ts at time zone c.tz),
         ((g.ts + make_interval(mins => v_dur)) at time zone c.tz),
         to_char(g.ts, 'HH24:MI')
    from public.working_hours w
   cross join lateral generate_series(
           p_date + w.start_time,
           p_date + w.end_time - make_interval(mins => v_dur),
           make_interval(mins => c.slot_step_min)) as g(ts)
   where w.provider_id = p_provider
     and w.weekday = extract(dow from p_date)::int
     and (g.ts at time zone c.tz) >= now() + make_interval(mins => c.min_notice_min)
     and not exists (
           select 1 from public.appointments a
            where a.provider_id = p_provider and a.status <> 'cancelled' and a.id <> v_excl
              and a.start_at < ((g.ts + make_interval(mins => v_dur)) at time zone c.tz)
              and a.end_at   > (g.ts at time zone c.tz))
   order by 1;
end $$;

-- Calendar of a month ('YYYY-MM'): free slot count per day + day-off flag.
create function public.month_availability(p_provider bigint, p_service bigint, p_month text, p_token text default null)
returns table (cal_date date, free_slots int, is_holiday boolean)
language plpgsql stable security definer set search_path = public as $$
declare v_first date;
begin
  if p_month is null or p_month !~ '^\d{4}-\d{2}$' then raise exception 'invalid_month'; end if;
  begin
    v_first := (p_month || '-01')::date;
  exception when others then raise exception 'invalid_month';
  end;
  perform 1 from public.get_slots(p_provider, p_service, v_first, p_token);   -- validates provider/service

  return query
  select d::date,
         (select count(*)::int from public.get_slots(p_provider, p_service, d::date, p_token)),
         exists (select 1 from public.holidays h
                  where h.day = d::date and (h.provider_id is null or h.provider_id = p_provider))
    from generate_series(v_first, (v_first + interval '1 month' - interval '1 day')::date, interval '1 day') d;
end $$;

-- ---------------------------------------------------------------- public catalogue helpers
create function public.list_providers(p_service bigint default null) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x order by (x->>'id')::bigint), '[]'::jsonb) from (
    select jsonb_build_object(
      'id', p.id, 'name_ar', p.name_ar, 'name_en', p.name_en,
      'specialty_ar', p.specialty_ar, 'specialty_en', p.specialty_en,
      'bio_ar', p.bio_ar, 'bio_en', p.bio_en,
      'serviceIds', coalesce((select jsonb_agg(ps.service_id order by ps.service_id)
                                from public.provider_services ps where ps.provider_id = p.id), '[]'::jsonb),
      'ratingAvg', (select round(avg(r.rating)::numeric, 1)::float8 from public.reviews r
                     where r.provider_id = p.id and r.approved),
      'ratingCount', (select count(*) from public.reviews r where r.provider_id = p.id and r.approved)
    ) as x
    from public.providers p
   where p.active
     and (p_service is null or exists (select 1 from public.provider_services ps
                                        where ps.provider_id = p.id and ps.service_id = p_service))
  ) t
$$;

-- Approved reviews only, newest first, first name only.
create function public.public_reviews(p_provider bigint default null, p_limit int default 12) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x order by (x->>'createdAt') desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'id', r.id, 'rating', r.rating, 'comment', r.comment,
      'createdAt', to_char(r.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
      'name', split_part(btrim(a.patient_name), ' ', 1),
      'provider', jsonb_build_object('id', p.id, 'nameAr', p.name_ar, 'nameEn', p.name_en)
    ) as x
    from public.reviews r
    join public.appointments a on a.id = r.appointment_id
    join public.providers p on p.id = r.provider_id
   where r.approved and (p_provider is null or r.provider_id = p_provider)
   order by r.created_at desc
   limit least(greatest(coalesce(p_limit, 12), 1), 50)
  ) t
$$;

-- ---------------------------------------------------------------- patient actions (anonymous, by secret token)
create function public.create_appointment(
  p_provider bigint, p_service bigint, p_start timestamptz,
  p_name text, p_phone text, p_email text default null, p_notes text default null, p_lang text default 'ar'
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  c public.clinic_settings; v_name text; v_phone text; v_email text; v_notes text; v_dur int;
  a public.appointments;
begin
  select * into c from public.clinic_settings;
  v_name  := public._clean_name(p_name);
  v_phone := public._clean_phone(p_phone);
  v_email := public._clean_email(p_email);
  v_notes := public._clean_notes(p_notes);
  if p_lang not in ('ar','en') or p_start is null then raise exception 'validation_error'; end if;

  perform pg_advisory_xact_lock(p_provider);    -- one booking at a time per doctor

  if not exists (select 1 from public.get_slots(p_provider, p_service, (p_start at time zone c.tz)::date) g
                  where g.slot_start = p_start) then
    raise exception 'slot_unavailable';
  end if;

  if (select count(*) from public.appointments
       where phone = v_phone and created_at > now() - interval '1 hour') >= 5 then
    raise exception 'too_many_requests';
  end if;
  if (select count(*) from public.appointments
       where phone = v_phone and status = 'confirmed' and start_at > now()) >= c.max_upcoming_per_phone then
    raise exception 'too_many_bookings';
  end if;

  select duration_min into v_dur from public.services where id = p_service;
  insert into public.appointments (provider_id, service_id, patient_name, phone, email, notes, start_at, end_at, lang)
  values (p_provider, p_service, v_name, v_phone, v_email, v_notes, p_start,
          p_start + make_interval(mins => v_dur), p_lang)
  returning * into a;
  return public._appt_json(a);
exception when exclusion_violation then
  raise exception 'slot_unavailable';
end $$;

create function public.get_appointment(p_token text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  return public._appt_json(public._by_token(p_token));
end $$;

-- p_patch keys (all optional): patientName, phone, email, notes, start (ISO instant)
create function public.update_appointment(p_token text, p_patch jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  c public.clinic_settings; a public.appointments;
  v_start timestamptz; v_end timestamptz;
begin
  if p_patch is null or p_patch = '{}'::jsonb then raise exception 'validation_error'; end if;
  select * into c from public.clinic_settings;

  a := public._by_token(p_token, true);
  perform pg_advisory_xact_lock(a.provider_id);
  a := public._by_token(p_token, true);
  if not public._can_modify(a) then raise exception 'cannot_modify'; end if;

  v_start := a.start_at; v_end := a.end_at;
  if p_patch ? 'start' then
    begin
      v_start := (p_patch->>'start')::timestamptz;
    exception when others then raise exception 'invalid_start';
    end;
    if not exists (select 1 from public.get_slots(a.provider_id, a.service_id,
                                                  (v_start at time zone c.tz)::date, p_token) g
                    where g.slot_start = v_start) then
      raise exception 'slot_unavailable';
    end if;
    v_end := v_start + (a.end_at - a.start_at);
  end if;

  update public.appointments set
    patient_name = case when p_patch ? 'patientName' then public._clean_name(p_patch->>'patientName')  else patient_name end,
    phone        = case when p_patch ? 'phone'       then public._clean_phone(p_patch->>'phone')       else phone end,
    email        = case when p_patch ? 'email'       then public._clean_email(p_patch->>'email')       else email end,
    notes        = case when p_patch ? 'notes'       then public._clean_notes(p_patch->>'notes')       else notes end,
    start_at = v_start, end_at = v_end
  where id = a.id
  returning * into a;
  return public._appt_json(a);
exception when exclusion_violation then
  raise exception 'slot_unavailable';
end $$;

create function public.cancel_appointment(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a public.appointments;
begin
  a := public._by_token(p_token, true);
  if a.status = 'cancelled' then raise exception 'already_cancelled'; end if;
  if not public._can_modify(a) then raise exception 'cannot_modify'; end if;
  update public.appointments set status = 'cancelled' where id = a.id returning * into a;
  return public._appt_json(a);
end $$;

create function public.create_review(p_token text, p_rating int, p_comment text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a public.appointments; v_comment text := nullif(btrim(coalesce(p_comment, '')), '');
begin
  if p_rating is null or p_rating not between 1 and 5 or char_length(coalesce(v_comment, '')) > 500 then
    raise exception 'validation_error';
  end if;
  a := public._by_token(p_token, true);
  if a.status <> 'completed' then raise exception 'cannot_review'; end if;
  if exists (select 1 from public.reviews where appointment_id = a.id) then raise exception 'already_reviewed'; end if;
  insert into public.reviews (appointment_id, provider_id, rating, comment)
  values (a.id, a.provider_id, p_rating, v_comment);
  return public._appt_json(a);
end $$;

-- ---------------------------------------------------------------- staff functions
-- Admin: all bookings (optionally one doctor). Doctor: always only their own.
create function public.staff_appointments(p_from date, p_to date, p_provider bigint default null) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare c public.clinic_settings; v_pid bigint;
begin
  select * into c from public.clinic_settings;
  if public.is_admin() then v_pid := p_provider;
  elsif public.my_provider_id() is not null then v_pid := public.my_provider_id();
  else raise exception 'forbidden';
  end if;
  if p_from is null or p_to is null or p_to < p_from then raise exception 'invalid_date'; end if;

  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', a.id, 'status', a.status,
      'start_at', to_char(a.start_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
      'end_at',   to_char(a.end_at   at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
      'patient_name', a.patient_name, 'phone', a.phone, 'email', a.email, 'notes', a.notes, 'lang', a.lang,
      'provider_id', a.provider_id, 'provider_name_en', p.name_en, 'provider_name_ar', p.name_ar,
      'service_id', a.service_id, 'service_name_en', s.name_en, 'service_name_ar', s.name_ar,
      'duration_min', s.duration_min) order by a.start_at)
    from public.appointments a
    join public.providers p on p.id = a.provider_id
    join public.services  s on s.id = a.service_id
   where a.start_at >= (p_from::timestamp at time zone c.tz)
     and a.start_at <  ((p_to + 1)::timestamp at time zone c.tz)
     and (v_pid is null or a.provider_id = v_pid)
  ), '[]'::jsonb);
end $$;

-- Admin: add a day off. Existing bookings are NOT cancelled; we return how many fall on that day.
create function public.admin_add_holiday(p_day date, p_provider bigint, p_reason_ar text default '', p_reason_en text default '')
returns jsonb
language plpgsql security definer set search_path = public as $$
declare c public.clinic_settings; v_id bigint; v_n int;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select * into c from public.clinic_settings;
  if p_day is null or p_day < (now() at time zone c.tz)::date then raise exception 'invalid_day'; end if;
  if p_provider is not null and not exists (select 1 from public.providers where id = p_provider) then
    raise exception 'provider_not_found';
  end if;
  begin
    insert into public.holidays (provider_id, day, reason_ar, reason_en)
    values (p_provider, p_day, left(coalesce(p_reason_ar, ''), 200), left(coalesce(p_reason_en, ''), 200))
    returning id into v_id;
  exception when unique_violation then raise exception 'holiday_exists';
  end;
  select count(*) into v_n from public.appointments a
   where a.status = 'confirmed'
     and a.start_at >= (p_day::timestamp at time zone c.tz)
     and a.start_at <  ((p_day + 1)::timestamp at time zone c.tz)
     and (p_provider is null or a.provider_id = p_provider);
  return jsonb_build_object('id', v_id, 'affectedAppointments', v_n);
end $$;

create function public.admin_stats(p_from date, p_to date, p_provider bigint default null) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare c public.clinic_settings; v jsonb;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  if p_from is null or p_to is null or p_to < p_from or p_to - p_from > 400 then raise exception 'invalid_date'; end if;
  select * into c from public.clinic_settings;

  with rws as (
    select a.status, a.provider_id, a.service_id, (a.start_at at time zone c.tz) as local_ts
      from public.appointments a
     where a.start_at >= (p_from::timestamp at time zone c.tz)
       and a.start_at <  ((p_to + 1)::timestamp at time zone c.tz)
       and (p_provider is null or a.provider_id = p_provider)
  ), act as (select * from rws where status <> 'cancelled')
  select jsonb_build_object(
    'range',  jsonb_build_object('from', p_from, 'to', p_to),
    'totals', jsonb_build_object(
        'total',     (select count(*) from rws),
        'confirmed', (select count(*) from rws where status = 'confirmed'),
        'completed', (select count(*) from rws where status = 'completed'),
        'cancelled', (select count(*) from rws where status = 'cancelled'),
        'noShow',    (select count(*) from rws where status = 'no_show')),
    'byWeekday', (select jsonb_agg(coalesce(x.n, 0) order by d) from generate_series(0, 6) d
                   left join (select extract(dow from local_ts)::int as k, count(*) as n from act group by 1) x on x.k = d),
    'byHour',    (select jsonb_agg(coalesce(x.n, 0) order by d) from generate_series(0, 23) d
                   left join (select extract(hour from local_ts)::int as k, count(*) as n from act group by 1) x on x.k = d),
    'byService', coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'nameAr', t.name_ar, 'nameEn', t.name_en, 'count', t.n) order by t.n desc)
                   from (select s.id, s.name_ar, s.name_en, count(*) as n from act join public.services s on s.id = act.service_id group by s.id) t), '[]'::jsonb),
    'byProvider', coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'nameAr', t.name_ar, 'nameEn', t.name_en, 'count', t.n) order by t.n desc)
                   from (select p.id, p.name_ar, p.name_en, count(*) as n from act join public.providers p on p.id = act.provider_id group by p.id) t), '[]'::jsonb),
    'byDay',     coalesce((select jsonb_agg(jsonb_build_object('date', t.day, 'count', t.n) order by t.day)
                   from (select to_char(local_ts, 'YYYY-MM-DD') as day, count(*) as n from act group by 1) t), '[]'::jsonb)
  ) into v;
  return v;
end $$;

-- ---------------------------------------------------------------- function permissions
-- Internal helpers: not callable from the browser.
revoke all on function public._appt_json(public.appointments), public._can_modify(public.appointments),
                       public._by_token(text, boolean),
                       public._clean_name(text), public._clean_phone(text),
                       public._clean_email(text), public._clean_notes(text)
  from public, anon, authenticated;

-- Public API (patients + website)
grant execute on function
  public.get_slots(bigint, bigint, date, text),
  public.month_availability(bigint, bigint, text, text),
  public.list_providers(bigint),
  public.public_reviews(bigint, int),
  public.create_appointment(bigint, bigint, timestamptz, text, text, text, text, text),
  public.get_appointment(text),
  public.update_appointment(text, jsonb),
  public.cancel_appointment(text),
  public.create_review(text, int, text)
  to anon, authenticated;

-- Staff API (each function checks the role again inside)
revoke all on function public.staff_appointments(date, date, bigint),
                       public.admin_add_holiday(date, bigint, text, text),
                       public.admin_stats(date, date, bigint)
  from public, anon;
grant execute on function
  public.staff_appointments(date, date, bigint),
  public.admin_add_holiday(date, bigint, text, text),
  public.admin_stats(date, date, bigint)
  to authenticated;
