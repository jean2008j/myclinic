# Clinic Booking — نظام حجز مواعيد العيادة

React + TypeScript (client) · **Supabase** (Postgres + Auth, no server of your own) · hosted on **GitHub Pages**.
Arabic (RTL) + English (LTR). Free bookings, on-screen confirmation, secret manage link for patients.

```
client/                      the website (Vite + React)
supabase/migrations/         database: tables, security rules (RLS), booking functions
supabase/seed.sql            demo doctors, services, working hours
supabase/create-staff.sql    link admin / doctor logins to their roles
.github/workflows/deploy.yml builds the client and publishes it to GitHub Pages
```

## 1. Supabase (once)
1. Create a project at supabase.com.
2. **SQL Editor** → paste and run `supabase/migrations/20261105000000_init.sql`.
3. Run `supabase/seed.sql` (demo data; edit it first if you want your real doctors/services).
4. **Authentication → Users → Add user** (tick *Auto Confirm*): one admin + one per doctor, real passwords.
   Then edit the emails in `supabase/create-staff.sql` and run it.
5. **Project Settings → API**: copy the *Project URL* and the *anon* key.

The anon key is public by design. What visitors can do is limited by the security rules in the migration
(patients only reach their booking through the secret token; staff tables need a login).

## 2. Run locally
```bash
cd client
cp .env.example .env      # fill in the two Supabase values
npm install
npm run dev               # http://localhost:5173
```

## 3. Publish on GitHub Pages
1. Push this repo to GitHub (branch `main`).
2. Repo → **Settings → Pages → Source: GitHub Actions**.
3. Repo → **Settings → Secrets and variables → Actions → New repository secret**:
   `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. Push (or run the workflow manually). The site appears at `https://<user>.github.io/<repo>/`.

Links use `#` (e.g. `…/#/manage/<token>`) because GitHub Pages cannot rewrite URLs; this is normal.

## 4. Supabase settings to check
- **Authentication → Providers → Email**: turn **off** "Allow new users to sign up" (staff accounts are created by you only).
- **Authentication → URL Configuration**: set *Site URL* to your GitHub Pages address.

## Notes
- Clinic time zone and booking rules live in the single row of `clinic_settings` (edit in Table Editor). Also keep `CLINIC_TZ` in `client/src/i18n/index.tsx` equal to it.
- Rate limiting per IP no longer exists (there is no server). Abuse is limited per phone number inside `create_appointment` (5 bookings/hour, max upcoming bookings). For more protection, enable Supabase's CAPTCHA for Auth, and consider an Edge Function if you need per-IP limits.
- Doctors/services/working hours are edited in the Supabase Table Editor (an admin screen for this is not built yet).
- No SMS / e-mail reminders: patients keep their private link.
- Seed accounts from the old version (`admin@clinic.local` …) no longer exist: create real accounts in step 1.4.
